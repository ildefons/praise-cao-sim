# B1 internal report: reviewed-through-8.1 snapshot

Sections 1 through 8.1 are preserved from the canonical working report. Sections after 8.1 and Appendices A-D contain titles only. This project is for internal review, not public release.

Import the entire ZIP into Overleaf. Select main.tex as the main file. Overleaf default pdfLaTeX works without compiler settings. The compiled PDF is included.

Canonical source SHA256: 381f939f52b422f90cd2ff6a5b79465610e9e681ff3cccd2d28de01dc139f12e
