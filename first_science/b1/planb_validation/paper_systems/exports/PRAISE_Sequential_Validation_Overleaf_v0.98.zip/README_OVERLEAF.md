# PRAISE sequential validation manuscript — Overleaf import

Version: v0.98, 23 November 2026.
Primary LaTeX file: main.tex.
Compiler: pdfLaTeX (standard Overleaf default).
Bibliography: embedded in main.tex; no BibTeX run required.
The two figure PDFs are bundled under figures/.
The package is self-contained; Overleaf does not need Python.
Generated from the GitHub praise-identifiability-feasibility branch.
